
export enum Category {
  Electronics = 'إلكترونيات',
  Furniture = 'أثاث',
  Cars = 'سيارات',
  Clothes = 'ملابس',
  Other = 'أخرى'
}

export enum JobCategory {
  Tech = 'تقني',
  Management = 'إدارة',
  Sales = 'مبيعات',
  Teaching = 'تعليم',
  Manual = 'مهني/يدوي'
}

export interface Item {
  id: string;
  title: string;
  price: number;
  category: Category;
  city: string;
  description: string;
  imageUrl: string;
  date: string;
  phone: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  category: JobCategory;
  city: string;
  salary: string;
  type: 'Full-time' | 'Part-time' | 'Remote';
  description: string;
  date: string;
}

export type View = 'home' | 'marketplace' | 'jobs' | 'post-item' | 'post-job';
