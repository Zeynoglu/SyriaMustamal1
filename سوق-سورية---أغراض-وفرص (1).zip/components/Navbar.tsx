
import React from 'react';
import { Home, ShoppingBag, Briefcase, PlusCircle, Menu } from 'lucide-react';
import { View } from '../types';

interface NavbarProps {
  currentView: View;
  setView: (view: View) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: 'home', label: 'الرئيسية', icon: <Home size={20} /> },
    { id: 'marketplace', label: 'سوق المستعمل', icon: <ShoppingBag size={20} /> },
    { id: 'jobs', label: 'فرص العمل', icon: <Briefcase size={20} /> },
  ];

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-8">
            <h1 
              className="text-2xl font-bold text-blue-600 cursor-pointer"
              onClick={() => setView('home')}
            >
              سوق سورية
            </h1>
            <div className="hidden md:flex gap-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setView(item.id as View)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    currentView === item.id ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <button
              onClick={() => setView('post-item')}
              className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-2 hover:bg-blue-700 transition-shadow shadow-md"
            >
              <PlusCircle size={18} />
              <span>أضف إعلان</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
