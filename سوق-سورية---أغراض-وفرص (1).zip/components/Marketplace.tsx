
import React, { useState } from 'react';
import { Search, MapPin, Tag, Phone } from 'lucide-react';
import { Item, Category } from '../types';

const MOCK_ITEMS: Item[] = [
  {
    id: '1',
    title: 'لابتوب ديل مستعمل بحالة ممتازة',
    price: 3500000,
    category: Category.Electronics,
    city: 'دمشق',
    description: 'لابتوب ديل i7، رام 16، هارد 512 SSD. مستعمل شهر واحد فقط، نظيف جداً.',
    imageUrl: 'https://picsum.photos/seed/laptop/400/300',
    date: 'منذ ساعتين',
    phone: '0933112233'
  },
  {
    id: '2',
    title: 'طقم كنب صالون تركي',
    price: 5200000,
    category: Category.Furniture,
    city: 'حلب',
    description: 'طقم كنب مؤلف من قطعتين كبيرتين وكرسيين. قماش مخمل لون بيج.',
    imageUrl: 'https://picsum.photos/seed/sofa/400/300',
    date: 'منذ يوم',
    phone: '0944556677'
  },
  {
    id: '3',
    title: 'هاتف آيفون 13 برو ماكس',
    price: 12000000,
    category: Category.Electronics,
    city: 'حمص',
    description: 'بطارية 92%، لا يوجد أي خدوش، مع كامل الملحقات.',
    imageUrl: 'https://picsum.photos/seed/phone/400/300',
    date: 'منذ 5 ساعات',
    phone: '0955889900'
  }
];

const Marketplace: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');

  const filteredItems = MOCK_ITEMS.filter(item => 
    (selectedCategory === 'all' || item.category === selectedCategory) &&
    (item.title.toLowerCase().includes(searchTerm.toLowerCase()) || item.city.includes(searchTerm))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <h2 className="text-2xl font-bold text-gray-800">سوق المستعمل</h2>
        <div className="relative w-full md:w-96">
          <input
            type="text"
            placeholder="ابحث عن (لابتوب، سيارة، دمشق...)"
            className="w-full pr-10 pl-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute right-3 top-2.5 text-gray-400" size={20} />
        </div>
      </div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${selectedCategory === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
        >
          الكل
        </button>
        {Object.values(Category).map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${selectedCategory === cat ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredItems.map(item => (
          <div key={item.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden border border-gray-100 flex flex-col">
            <img src={item.imageUrl} alt={item.title} className="h-48 w-full object-cover" />
            <div className="p-4 flex-1 flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <span className="text-blue-600 font-bold text-lg">{item.price.toLocaleString()} ل.س</span>
                <span className="bg-blue-50 text-blue-600 text-xs px-2 py-1 rounded-full font-medium">{item.category}</span>
              </div>
              <h3 className="text-gray-900 font-semibold mb-2 line-clamp-2">{item.title}</h3>
              <div className="flex items-center text-gray-500 text-xs gap-4 mt-auto">
                <div className="flex items-center gap-1">
                  <MapPin size={14} />
                  <span>{item.city}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span>{item.date}</span>
                </div>
              </div>
              <button className="w-full mt-4 bg-green-500 text-white py-2 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-green-600 transition-colors">
                <Phone size={18} />
                تواصل الآن
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {filteredItems.length === 0 && (
        <div className="text-center py-20 text-gray-500">
          <p className="text-xl">لم يتم العثور على نتائج تطابق بحثك.</p>
        </div>
      )}
    </div>
  );
};

export default Marketplace;
