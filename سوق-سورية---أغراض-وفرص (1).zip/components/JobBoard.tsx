
import React, { useState } from 'react';
import { Briefcase, MapPin, Building2, Clock, DollarSign } from 'lucide-react';
import { Job, JobCategory } from '../types';

const MOCK_JOBS: Job[] = [
  {
    id: '1',
    title: 'مطور واجهات أمامية (React)',
    company: 'شركة تك للحلول البرمجية',
    category: JobCategory.Tech,
    city: 'دمشق',
    salary: '4,000,000 - 6,000,000 ل.س',
    type: 'Full-time',
    description: 'نبحث عن مطور ذو خبرة في React و Tailwind CSS للانضمام إلى فريقنا المتميز.',
    date: 'منذ يوم'
  },
  {
    id: '2',
    title: 'مندوب مبيعات ميداني',
    company: 'مجموعة المأمون التجارية',
    category: JobCategory.Sales,
    city: 'حلب',
    salary: '2,500,000 ل.س + عمولات',
    type: 'Full-time',
    description: 'توزيع وتسويق منتجات غذائية، يفضل امتلاك وسيلة نقل.',
    date: 'منذ ساعتين'
  },
  {
    id: '3',
    title: 'مدرس لغة إنجليزية',
    company: 'مركز اللغات التخصصي',
    category: JobCategory.Teaching,
    city: 'اللاذقية',
    salary: 'حسب الحصص',
    type: 'Part-time',
    description: 'إعطاء دورات TOEFL و IELTS، خبرة سنتين على الأقل.',
    date: 'منذ 3 أيام'
  }
];

const JobBoard: React.FC = () => {
  const [selectedCat, setSelectedCat] = useState<JobCategory | 'all'>('all');

  const filteredJobs = MOCK_JOBS.filter(job => 
    selectedCat === 'all' || job.category === selectedCat
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">فرص العمل في سوريا</h2>
        <p className="text-gray-600">جد وظيفتك القادمة من بين مئات الإعلانات المحدثة يومياً</p>
      </div>

      <div className="flex gap-2 mb-8 overflow-x-auto pb-2 justify-center">
        <button
          onClick={() => setSelectedCat('all')}
          className={`px-6 py-2 rounded-full whitespace-nowrap transition-colors shadow-sm ${selectedCat === 'all' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border hover:bg-gray-50'}`}
        >
          كل الوظائف
        </button>
        {Object.values(JobCategory).map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCat(cat)}
            className={`px-6 py-2 rounded-full whitespace-nowrap transition-colors shadow-sm ${selectedCat === cat ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border hover:bg-gray-50'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {filteredJobs.map(job => (
          <div key={job.id} className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow group">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">{job.title}</h3>
                  <span className="bg-blue-50 text-blue-600 text-xs px-2 py-1 rounded-md font-medium">{job.type === 'Full-time' ? 'دوام كامل' : job.type === 'Part-time' ? 'دوام جزئي' : 'عن بعد'}</span>
                </div>
                <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-gray-500 text-sm">
                  <div className="flex items-center gap-1">
                    <Building2 size={16} />
                    <span>{job.company}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin size={16} />
                    <span>{job.city}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <DollarSign size={16} />
                    <span>{job.salary}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>{job.date}</span>
                  </div>
                </div>
                <p className="mt-3 text-gray-600 text-sm line-clamp-2">{job.description}</p>
              </div>
              <button className="bg-blue-600 text-white px-8 py-2 rounded-lg font-bold hover:bg-blue-700 transition-colors whitespace-nowrap">
                قدم الآن
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default JobBoard;
