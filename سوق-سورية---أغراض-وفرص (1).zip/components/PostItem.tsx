
import React, { useState } from 'react';
import { Camera, Sparkles, Loader2, CheckCircle } from 'lucide-react';
import { generateItemDescription } from '../services/geminiService';
import { Category } from '../types';

const PostItem: React.FC = () => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(Category.Electronics);
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [posted, setPosted] = useState(false);

  const handleAIDescription = async () => {
    if (!title) return alert('يرجى كتابة عنوان أولاً');
    setIsGenerating(true);
    const result = await generateItemDescription(title, category);
    setDescription(result || '');
    setIsGenerating(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPosted(true);
    setTimeout(() => setPosted(false), 3000);
  };

  if (posted) {
    return (
      <div className="max-w-xl mx-auto mt-20 p-8 bg-white rounded-2xl shadow-xl text-center">
        <div className="flex justify-center mb-4">
          <CheckCircle size={64} className="text-green-500 animate-bounce" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">تم النشر بنجاح!</h2>
        <p className="text-gray-600">إعلانك الآن قيد المراجعة وسيظهر للجميع قريباً.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">أضف إعلانك في ثوانٍ</h2>
      
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 space-y-6">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">عنوان الإعلان</label>
          <input
            required
            type="text"
            className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="مثال: لابتوب آسوس جديد"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">الفئة</label>
            <select
              className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
            >
              {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">السعر (ل.س)</label>
            <input
              required
              type="number"
              className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="0.00"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
          </div>
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-sm font-semibold text-gray-700">وصف الغرض</label>
            <button
              type="button"
              onClick={handleAIDescription}
              disabled={isGenerating}
              className="text-xs flex items-center gap-1 text-purple-600 font-bold hover:text-purple-700 disabled:opacity-50"
            >
              {isGenerating ? <Loader2 className="animate-spin" size={14} /> : <Sparkles size={14} />}
              توليد وصف بالذكاء الاصطناعي
            </button>
          </div>
          <textarea
            required
            rows={4}
            className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none resize-none"
            placeholder="اكتب تفاصيل إضافية هنا..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>

        <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center hover:border-blue-400 transition-colors cursor-pointer group">
          <input type="file" className="hidden" id="file-upload" />
          <label htmlFor="file-upload" className="cursor-pointer">
            <Camera className="mx-auto mb-2 text-gray-400 group-hover:text-blue-500" size={40} />
            <p className="text-gray-500">اضغط لرفع صور المنتج</p>
            <p className="text-xs text-gray-400 mt-1">يمكنك رفع حتى 5 صور</p>
          </label>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all transform hover:scale-[1.01] active:scale-95 shadow-lg"
        >
          نشر الإعلان الآن
        </button>
      </form>
    </div>
  );
};

export default PostItem;
