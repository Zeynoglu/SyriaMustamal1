
import React, { useState } from 'react';
import { View } from './types';
import Navbar from './components/Navbar';
import Marketplace from './components/Marketplace';
import JobBoard from './components/JobBoard';
import PostItem from './components/PostItem';
import { ShoppingBag, Briefcase, Zap, Heart, TrendingUp, Facebook, Twitter, Instagram, Mail } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setView] = useState<View>('home');

  const renderContent = () => {
    switch (currentView) {
      case 'marketplace':
        return <Marketplace />;
      case 'jobs':
        return <JobBoard />;
      case 'post-item':
        return <PostItem />;
      case 'home':
      default:
        return (
          <div className="animate-in fade-in duration-500">
            {/* Hero Section */}
            <div className="relative overflow-hidden bg-gradient-to-br from-blue-700 to-indigo-900 py-24 text-white">
              <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
                <h1 className="text-5xl md:text-6xl font-extrabold mb-6 drop-shadow-lg">
                  كل ما تحتاجه في مكان واحد
                </h1>
                <p className="text-xl md:text-2xl mb-10 text-blue-100 max-w-3xl mx-auto font-light">
                  سوق سورية - منصتك الموثوقة لبيع وشراء الأدوات المستعملة وإيجاد أفضل فرص العمل في جميع المحافظات السورية.
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                  <button 
                    onClick={() => setView('marketplace')}
                    className="bg-white text-blue-700 px-8 py-4 rounded-full font-bold text-lg hover:bg-blue-50 transition-all shadow-xl flex items-center gap-2"
                  >
                    <ShoppingBag size={24} />
                    تصفح السوق
                  </button>
                  <button 
                    onClick={() => setView('jobs')}
                    className="bg-transparent border-2 border-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-blue-700 transition-all flex items-center gap-2"
                  >
                    <Briefcase size={24} />
                    ابحث عن عمل
                  </button>
                </div>
              </div>
              <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl"></div>
            </div>

            {/* Features Section */}
            <div className="max-w-7xl mx-auto px-4 py-20">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center hover:transform hover:-translate-y-2 transition-all">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Zap className="text-blue-600" size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-3">سرعة في النشر</h3>
                  <p className="text-gray-600">انشر إعلانك خلال دقيقة واحدة فقط بفضل تقنيات الذكاء الاصطناعي التي تساعدك في كتابة الوصف.</p>
                </div>
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center hover:transform hover:-translate-y-2 transition-all">
                  <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Heart className="text-red-600" size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-3">ثقة وأمان</h3>
                  <p className="text-gray-600">نحن نراجع كافة الإعلانات لضمان توفير بيئة آمنة للمشترين وأصحاب العمل.</p>
                </div>
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center hover:transform hover:-translate-y-2 transition-all">
                  <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                    <TrendingUp className="text-green-600" size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-3">فرص متجددة</h3>
                  <p className="text-gray-600">مئات الوظائف الجديدة تضاف يومياً من أفضل الشركات والمؤسسات السورية.</p>
                </div>
              </div>
            </div>

            {/* Call to Action */}
            <div className="bg-white border-y border-gray-100 py-16">
              <div className="max-w-4xl mx-auto text-center px-4">
                <h2 className="text-3xl font-bold mb-6">هل لديك شيء تود بيعه؟</h2>
                <p className="text-gray-600 mb-8 text-lg">انضم إلى آلاف السوريين الذين يستخدمون منصتنا يومياً لبيع أغراضهم والحصول على دخل إضافي.</p>
                <button 
                  onClick={() => setView('post-item')}
                  className="bg-blue-600 text-white px-10 py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all shadow-lg"
                >
                  أضف إعلانك الأول مجاناً
                </button>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar currentView={currentView} setView={setView} />
      
      <main className="flex-grow">
        {renderContent()}
      </main>

      <footer className="bg-gray-900 text-gray-300 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-8 text-right">
            <div className="col-span-1 md:col-span-1">
              <h3 className="text-white text-xl font-bold mb-6">سوق سورية</h3>
              <p className="text-sm leading-relaxed">
                المنصة الأولى والوحيدة في سوريا التي تجمع بين تجارة المستعمل وفرص العمل في مكان واحد، لخدمة المجتمع السوري وتسهيل الحياة اليومية.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-6">روابط سريعة</h4>
              <ul className="space-y-4 text-sm">
                <li><button onClick={() => setView('home')} className="hover:text-white transition-colors">الرئيسية</button></li>
                <li><button onClick={() => setView('marketplace')} className="hover:text-white transition-colors">سوق المستعمل</button></li>
                <li><button onClick={() => setView('jobs')} className="hover:text-white transition-colors">فرص العمل</button></li>
                <li><button className="hover:text-white transition-colors">عن المنصة</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-6">المحافظات</h4>
              <ul className="space-y-4 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">دمشق وريفها</a></li>
                <li><a href="#" className="hover:text-white transition-colors">حلب</a></li>
                <li><a href="#" className="hover:text-white transition-colors">حمص وحماة</a></li>
                <li><a href="#" className="hover:text-white transition-colors">اللاذقية وطرطوس</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-6">تواصل معنا</h4>
              <div className="flex gap-4 mb-6 justify-end">
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-blue-600 transition-colors"><Facebook size={20} /></a>
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-blue-400 transition-colors"><Twitter size={20} /></a>
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-pink-600 transition-colors"><Instagram size={20} /></a>
                <a href="#" className="bg-gray-800 p-2 rounded-full hover:bg-red-600 transition-colors"><Mail size={20} /></a>
              </div>
              <p className="text-xs">حقوق النشر © 2024 سوق سورية. جميع الحقوق محفوظة.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
