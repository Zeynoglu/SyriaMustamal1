
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateItemDescription = async (title: string, category: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `اكتب وصفاً جذاباً واحترافياً باللغة العربية لغرض مستعمل للبيع بعنوان: "${title}" في قسم "${category}". ركز على الحالة الجيدة والسعر المناسب. اجعل النص مختصراً ومشجعاً للشراء.`,
      config: {
        temperature: 0.7,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "خطأ في توليد الوصف. يرجى كتابة الوصف يدوياً.";
  }
};

export const suggestJobImprovements = async (jobTitle: string, description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `أنا صاحب عمل في سوريا أريد تحسين إعلان وظيفة لـ "${jobTitle}". الوصف الحالي هو: "${description}". يرجى إعادة صياغته بشكل احترافي ليجذب أفضل الكفاءات، مع إضافة مهارات مقترحة.`,
      config: {
        temperature: 0.8,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "لا يمكن تحسين الوصف حالياً.";
  }
};
